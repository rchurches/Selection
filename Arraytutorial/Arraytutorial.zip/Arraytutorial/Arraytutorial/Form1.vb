﻿Public Class Form1
    Public MyNumbers(), number() As Integer
    Public rangenum As Byte



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        lstResult.Items.Clear()

        rangenum = InputBox("Enter how many numbers you want generated maximum is 255")
        ReDim MyNumbers(rangenum), number(rangenum)
        For count = 1 To rangenum
            Randomize()
            number(count) = count
            MyNumbers(count) = Int(Rnd() * 20) + 1
            lstResult.Items.Add("Number " & count & " is " & MyNumbers(count))
        Next

    End Sub

    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        Dim usercheck As Integer
        usercheck = CInt(InputBox("Which number do you want to know?"))
        MsgBox(usercheck & "  is " & MyNumbers(usercheck))
    End Sub

    Private Sub btnSort_Click(sender As Object, e As EventArgs) Handles btnSort.Click
        lstResult.Items.Add(vbCrLf)
        Array.Sort(MyNumbers, number)
        For count = 1 To rangenum
            Randomize()
            ' number(count) = count
            ' MyNumbers(count) = Int(Rnd() * 20) + 1
            lstResult.Items.Add("Number " & number(count) & " is " & MyNumbers(count))
        Next
    End Sub
End Class
